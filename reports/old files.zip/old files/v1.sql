-- Criação das tabelas relacionadas a Cliente
CREATE TABLE cliente
(
	cpf char(11) unique,
	nome varchar(127) not null,
	rg varchar(31) not null,
	sexo char(1) null,
	nascimento date not null,
	celular char(11)  not null,
	telefone char(10) null,
	PRIMARY KEY (cpf)
);

CREATE TABLE endereco
(
	id serial,
	rua varchar(127) not null,
	numero varchar(10) null,
	complemento varchar(127) null,
	bairro varchar(127) not null,
	cidade varchar(127) not null,
	estado 	varchar(31) not null,
	cliente_cpf char(11),
	PRIMARY KEY (id),
	FOREIGN KEY (cliente_cpf) REFERENCES cliente (cpf)
);

create table conta (
	id serial, 
	conta_devedor numeric(6,2) not null default 0.00,
	cliente_cpf char(11),
	PRIMARY KEY (ID),
	FOREIGN KEY (cliente_cpf) REFERENCES cliente(cpf)
);

-- Tabelas Referente a Venda

create table venda (
	id serial,
	data timestamp not null,
	dataVencimento date not null,
	formaPagamento varchar(50) not null,
	vendaPrazo boolean not null,
	cliente_cpf char(11),
	PRIMARY KEY (id),
	FOREIGN KEY (cliente_cpf) REFERENCES cliente(cpf)
);

create table produto (
	id serial,
	nome varchar(127) not null,
	descricao varchar(255) null,
	observacao varchar(255) null,
	estoque varchar(3) not null default 0,
	preco_custo decimal(6,2) not null,
	preco_venda decimal(6,2) not null,
	PRIMARY KEY (id)
);

create table venda_produto(
	produto_ID serial,
	venda_ID serial
);

ALTER TABLE venda_produto ADD PRIMARY KEY (produto_ID, venda_ID);
ALTER TABLE venda_produto ADD FOREIGN KEY (produto_ID) REFERENCES produto(id);
ALTER TABLE venda_produto ADD FOREIGN KEY (venda_ID) REFERENCES venda(id);



