-- Criação do Baco de Dados do Sispani
CREATE DATABASE sispani;

-- Criação das tabelas relacionadas a Cliente
CREATE TABLE cliente
(
	cpf CHAR(11) UNIQUE,
	nome VARCHAR(127),
	rg VARCHAR(31),
	sexo CHAR(1),
	nascimento DATE,
	celular CHAR(11),
	telefone CHAR(10),
	PRIMARY KEY (cpf)
);

CREATE TABLE endereco
(
	id SERIAL,
	rua VARCHAR(127),
	numero VARCHAR(10),
	complemento VARCHAR(127),
	barirro VARCHAR(127),
	cidade VARCHAR(127),
	estado 	VARCHAR(31),
	cliente_cpf CHAR(11),
	PRIMARY KEY (id),
	FOREIGN KEY (cliente_cpf) REFERENCES cliente (cpf)
);