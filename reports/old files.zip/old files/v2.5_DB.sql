-- Criação das tabelas relacionadas a Cliente
CREATE TABLE cliente
(
	cpf char(11) unique,
	nome varchar(127) not null,
	rg varchar(31) not null,
	sexo char(1) not null,
	nascimento date not null,
	celular char(11)  not null,
	telefone char(10) null,
	PRIMARY KEY (cpf)
);

CREATE TABLE endereco
(
	id serial,
	rua varchar(127) not null,
	numero varchar(10) not null,
	complemento varchar(127) null,
	bairro varchar(127) not null,
	cidade varchar(127) not null,
	estado 	varchar(31) not null,
	cliente_cpf char(11),
	PRIMARY KEY (id),
	FOREIGN KEY (cliente_cpf) REFERENCES cliente (cpf)
);

create table conta (
	id serial, 
	conta_devedor numeric(6,2) not null default 0.00,
	cliente_cpf char(11),
	PRIMARY KEY (ID),
	FOREIGN KEY (cliente_cpf) REFERENCES cliente(cpf)
);

-- Tabelas Referente a Venda

create table venda (
	id serial,
	data timestamp not null,
	dataVencimento date not null,
	formaPagamento varchar(50) not null,
	vendaPrazo boolean not null,
	cliente_cpf char(11),
	PRIMARY KEY (id),
	FOREIGN KEY (cliente_cpf) REFERENCES cliente(cpf)
);

create table produto (
	id serial,
	nome varchar(127) not null,
	descricao varchar(255) null,
	observacao varchar(255) null,
	estoque varchar(3) not null default 0,
	preco_custo decimal(6,2) not null,
	preco_venda decimal(6,2) not null,
	PRIMARY KEY (id)
);

create table venda_produto(
	produto_ID serial,
	venda_ID serial
);

ALTER TABLE venda_produto ADD PRIMARY KEY (produto_ID, venda_ID);
ALTER TABLE venda_produto ADD FOREIGN KEY (produto_ID) REFERENCES produto(id);
ALTER TABLE venda_produto ADD FOREIGN KEY (venda_ID) REFERENCES venda(id);

-- Funções

create or replace function inserir_cliente(cpf_ char(11), nome_ varchar(127), rg_ varchar(31), sexo_ char(1), nascimento_ date, celular_ char(11), telefone_ char(10), rua_ varchar(127), numero_ varchar(10), complemento_ varchar(127), bairro_ varchar(127), cidade_ varchar(127), estado_ varchar(31), cliente_cpf_ char(11)) returns boolean as $$
BEGIN
	if (telefone_ is null or telefone_ = '0' or telefone_ = '') then
		insert into cliente (cpf, nome, rg, sexo, nascimento, celular) values (cpf_, nome_, rg_, sexo_, nascimento_, celular_);
	else
		insert into cliente (cpf, nome, rg, sexo, nascimento, celular, telefone) values (cpf_, nome_, rg_, sexo_, nascimento_, celular_, telefone_);
	end if;
	
	if (complemento_ is null or complemento_ = '0' or complemento_ = '') then
		insert into endereco (rua, numero, bairro, cidade, estado, cliente_cpf) values (rua_, numero_, bairro_, cidade_, estado_, cliente_cpf_);
		return true;
	else
		insert into endereco (rua, numero, complemento, bairro, cidade, estado, cliente_cpf) values (rua_, numero_, complemento_, bairro_, cidade_, estado_, cliente_cpf_);
		return true;
	end if;
	
	return false;
END;
$$ LANGUAGE plpgsql;

create type select_cliente_endereco as (
	cpf char(11),
	nome varchar(127),
	rg varchar(31),
	sexo char(1),
	nascimento date,
	celular char(11),
	telefone char(10),
	rua varchar(127),
	numero varchar(10),
	complemento varchar(127),
	bairro varchar(127),
	cidade varchar(127),
	estado 	varchar(31)
);

create or replace function selecionar_cliente(cliente_cpf_ char(11)) returns setof select_cliente_endereco as $$
DECLARE
	dados_cliente select_cliente_endereco;
BEGIN
	FOR dados_cliente in select c.cpf, c.nome, c.rg, c.sexo, c.nascimento, c.celular, c.telefone, e.rua, e.numero,
	e.complemento, e.bairro, e.cidade, e.estado
	from cliente c, endereco e 
	where c.cpf = e.cliente_cpf and c.cpf = cliente_cpf_ LOOP
		return next dados_cliente;
	END LOOP;
END;
$$ LANGUAGE plpgsql;

create or replace function alterar_cliente(cpf_ char(11), nome_ varchar(127), sexo_ char(1), celular_ char(11), telefone_ char(10), rua_ varchar(127), numero_ varchar(10), complemento_ varchar(127), bairro_ varchar(127), cidade_ varchar(127), estado_ varchar(31)) returns void as $$
BEGIN
	if (telefone_ is null or telefone_ = '0' or telefone_ = '') then
		update cliente set nome = nome_, sexo = sexo_, celular = celular_, telefone = null where cpf = cpf_;
	else
		update cliente set nome = nome_, sexo = sexo_, celular = celular_, telefone = telefone_ where cpf = cpf_;
	end if;
	
	if (complemento_ is null or complemento_ = '0' or complemento_ = '') then
		update endereco set rua = rua_, numero = numero_, complemento = null, bairro = bairro_, cidade = cidade_, estado = estado_ where cliente_cpf = cpf_;
	else
		update endereco set rua = rua_, numero = numero_, complemento = complemento_, bairro = bairro_, cidade = cidade_, estado = estado_ where cliente_cpf = cpf_;
	end if;
END;
$$ LANGUAGE plpgsql;

create or replace function excluir_cliente(cpf_ char(11)) returns void as $$
BEGIN
	delete from endereco where cliente_cpf = cpf_;
	delete from cliente where cpf = cpf_;	
END;
$$ LANGUAGE plpgsql;

